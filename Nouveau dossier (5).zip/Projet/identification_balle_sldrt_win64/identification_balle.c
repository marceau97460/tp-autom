/*
 * identification_balle.c
 *
 * Classroom License -- for classroom instructional use only.  Not for
 * government, commercial, academic research, or other organizational use.
 *
 * Code generation for model "identification_balle".
 *
 * Model version              : 1.18
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Tue May 23 15:38:57 2023
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "identification_balle.h"
#include "identification_balle_private.h"
#include "identification_balle_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6024E", 4294967295U, 6, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_identification_balle_T identification_balle_B;

/* Block states (default storage) */
DW_identification_balle_T identification_balle_DW;

/* Real-time model */
RT_MODEL_identification_balle_T identification_balle_M_;
RT_MODEL_identification_balle_T *const identification_balle_M =
  &identification_balle_M_;
real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T tmp;
  real_T tmp_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    tmp = fabs(u0);
    tmp_0 = fabs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = (rtNaN);
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

/* Model output function */
void identification_balle_output(void)
{
  real_T denAccum;

  /* Step: '<Root>/Step' */
  if (identification_balle_M->Timing.t[0] < identification_balle_P.Step_Time) {
    identification_balle_B.Step = identification_balle_P.Step_Y0;
  } else {
    identification_balle_B.Step = identification_balle_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */

  /* S-Function (sldrtai): '<Root>/Analog Input1' */
  /* S-Function Block: <Root>/Analog Input1 */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE) identification_balle_P.AnalogInput1_RangeMode;
    parm.rangeidx = identification_balle_P.AnalogInput1_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1,
                   &identification_balle_P.AnalogInput1_Channels,
                   &identification_balle_B.AnalogInput1, &parm);
  }

  /* Fcn: '<Root>/Fcn1' */
  denAccum = 98.01 - (identification_balle_B.AnalogInput1 - 7.65) * 126.28;
  if (denAccum < 0.0) {
    denAccum = -sqrt(-denAccum);
  } else {
    denAccum = sqrt(denAccum);
  }

  identification_balle_B.Fcn1 = -4.905 * rt_powd_snf(denAccum + 9.9, 2.0) /
    3986.7 + 0.77;

  /* End of Fcn: '<Root>/Fcn1' */
  /* Sum: '<Root>/Add1' */
  identification_balle_B.Add1 = identification_balle_B.Step -
    identification_balle_B.Fcn1;

  /* DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn' */
  identification_balle_DW.DiscreteTransferFcn_tmp = (identification_balle_B.Add1
    - identification_balle_P.DiscreteTransferFcn_DenCoef[1] *
    identification_balle_DW.DiscreteTransferFcn_states) /
    identification_balle_P.DiscreteTransferFcn_DenCoef[0];
  identification_balle_B.DiscreteTransferFcn =
    identification_balle_P.DiscreteTransferFcn_NumCoef[0] *
    identification_balle_DW.DiscreteTransferFcn_tmp +
    identification_balle_P.DiscreteTransferFcn_NumCoef[1] *
    identification_balle_DW.DiscreteTransferFcn_states;

  /* S-Function (sldrtao): '<Root>/Analog Output1' */
  /* S-Function Block: <Root>/Analog Output1 */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) identification_balle_P.AnalogOutput1_RangeMode;
      parm.rangeidx = identification_balle_P.AnalogOutput1_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &identification_balle_P.AnalogOutput1_Channels, ((real_T*)
        (&identification_balle_B.DiscreteTransferFcn)), &parm);
    }
  }
}

/* Model update function */
void identification_balle_update(void)
{
  /* Update for DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn' */
  identification_balle_DW.DiscreteTransferFcn_states =
    identification_balle_DW.DiscreteTransferFcn_tmp;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++identification_balle_M->Timing.clockTick0)) {
    ++identification_balle_M->Timing.clockTickH0;
  }

  identification_balle_M->Timing.t[0] =
    identification_balle_M->Timing.clockTick0 *
    identification_balle_M->Timing.stepSize0 +
    identification_balle_M->Timing.clockTickH0 *
    identification_balle_M->Timing.stepSize0 * 4294967296.0;

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++identification_balle_M->Timing.clockTick1)) {
      ++identification_balle_M->Timing.clockTickH1;
    }

    identification_balle_M->Timing.t[1] =
      identification_balle_M->Timing.clockTick1 *
      identification_balle_M->Timing.stepSize1 +
      identification_balle_M->Timing.clockTickH1 *
      identification_balle_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Model initialize function */
void identification_balle_initialize(void)
{
  /* Start for S-Function (sldrtao): '<Root>/Analog Output1' */

  /* S-Function Block: <Root>/Analog Output1 */

  /* no initial value should be set */

  /* InitializeConditions for DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn' */
  identification_balle_DW.DiscreteTransferFcn_states =
    identification_balle_P.DiscreteTransferFcn_InitialStates;
}

/* Model terminate function */
void identification_balle_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output1' */

  /* S-Function Block: <Root>/Analog Output1 */

  /* no final value should be set */
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  identification_balle_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  identification_balle_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  identification_balle_initialize();
}

void MdlTerminate(void)
{
  identification_balle_terminate();
}

/* Registration function */
RT_MODEL_identification_balle_T *identification_balle(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  identification_balle_P.AnalogInput1_MaxMissedTicks = rtInf;
  identification_balle_P.AnalogOutput1_MaxMissedTicks = rtInf;

  /* initialize real-time model */
  (void) memset((void *)identification_balle_M, 0,
                sizeof(RT_MODEL_identification_balle_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&identification_balle_M->solverInfo,
                          &identification_balle_M->Timing.simTimeStep);
    rtsiSetTPtr(&identification_balle_M->solverInfo, &rtmGetTPtr
                (identification_balle_M));
    rtsiSetStepSizePtr(&identification_balle_M->solverInfo,
                       &identification_balle_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&identification_balle_M->solverInfo,
                          (&rtmGetErrorStatus(identification_balle_M)));
    rtsiSetRTModelPtr(&identification_balle_M->solverInfo,
                      identification_balle_M);
  }

  rtsiSetSimTimeStep(&identification_balle_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&identification_balle_M->solverInfo,"FixedStepDiscrete");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = identification_balle_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    identification_balle_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    identification_balle_M->Timing.sampleTimes =
      (&identification_balle_M->Timing.sampleTimesArray[0]);
    identification_balle_M->Timing.offsetTimes =
      (&identification_balle_M->Timing.offsetTimesArray[0]);

    /* task periods */
    identification_balle_M->Timing.sampleTimes[0] = (0.0);
    identification_balle_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    identification_balle_M->Timing.offsetTimes[0] = (0.0);
    identification_balle_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(identification_balle_M, &identification_balle_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = identification_balle_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    identification_balle_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(identification_balle_M, 20.0);
  identification_balle_M->Timing.stepSize0 = 0.001;
  identification_balle_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  identification_balle_M->Sizes.checksums[0] = (2911732278U);
  identification_balle_M->Sizes.checksums[1] = (1103598092U);
  identification_balle_M->Sizes.checksums[2] = (452168063U);
  identification_balle_M->Sizes.checksums[3] = (735765506U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    identification_balle_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(identification_balle_M->extModeInfo,
      &identification_balle_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(identification_balle_M->extModeInfo,
                        identification_balle_M->Sizes.checksums);
    rteiSetTPtr(identification_balle_M->extModeInfo, rtmGetTPtr
                (identification_balle_M));
  }

  identification_balle_M->solverInfoPtr = (&identification_balle_M->solverInfo);
  identification_balle_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&identification_balle_M->solverInfo, 0.001);
  rtsiSetSolverMode(&identification_balle_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  identification_balle_M->blockIO = ((void *) &identification_balle_B);
  (void) memset(((void *) &identification_balle_B), 0,
                sizeof(B_identification_balle_T));

  /* parameters */
  identification_balle_M->defaultParam = ((real_T *)&identification_balle_P);

  /* states (dwork) */
  identification_balle_M->dwork = ((void *) &identification_balle_DW);
  (void) memset((void *)&identification_balle_DW, 0,
                sizeof(DW_identification_balle_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    identification_balle_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  identification_balle_M->Sizes.numContStates = (0);/* Number of continuous states */
  identification_balle_M->Sizes.numY = (0);/* Number of model outputs */
  identification_balle_M->Sizes.numU = (0);/* Number of model inputs */
  identification_balle_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  identification_balle_M->Sizes.numSampTimes = (2);/* Number of sample times */
  identification_balle_M->Sizes.numBlocks = (11);/* Number of blocks */
  identification_balle_M->Sizes.numBlockIO = (5);/* Number of block outputs */
  identification_balle_M->Sizes.numBlockPrms = (18);/* Sum of parameter "widths" */
  return identification_balle_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
