/*
 * identification_moteur.c
 *
 * Classroom License -- for classroom instructional use only.  Not for
 * government, commercial, academic research, or other organizational use.
 *
 * Code generation for model "identification_moteur".
 *
 * Model version              : 1.4
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Fri Apr 21 15:53:48 2023
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "identification_moteur.h"
#include "identification_moteur_private.h"
#include "identification_moteur_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6024E", 4294967295U, 6, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_identification_moteur_T identification_moteur_B;

/* Block states (default storage) */
DW_identification_moteur_T identification_moteur_DW;

/* Real-time model */
RT_MODEL_identification_moteur_T identification_moteur_M_;
RT_MODEL_identification_moteur_T *const identification_moteur_M =
  &identification_moteur_M_;

/* Model output function */
void identification_moteur_output(void)
{
  real_T rtb_Add1;

  /* FromWorkspace: '<Root>/From Workspace' */
  {
    real_T *pDataValues = (real_T *)
      identification_moteur_DW.FromWorkspace_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *)
      identification_moteur_DW.FromWorkspace_PWORK.TimePtr;
    int_T currTimeIndex = identification_moteur_DW.FromWorkspace_IWORK.PrevIndex;
    real_T t = identification_moteur_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[496]) {
      currTimeIndex = 495;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    identification_moteur_DW.FromWorkspace_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          identification_moteur_B.FromWorkspace = pDataValues[currTimeIndex];
        } else {
          identification_moteur_B.FromWorkspace = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        identification_moteur_B.FromWorkspace = (real_T) rtInterpolate(d1, d2,
          f1, f2);
        pDataValues += 497;
      }
    }
  }

  /* S-Function (sldrtai): '<Root>/Analog Input' */
  /* S-Function Block: <Root>/Analog Input */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE) identification_moteur_P.AnalogInput_RangeMode;
    parm.rangeidx = identification_moteur_P.AnalogInput_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1,
                   &identification_moteur_P.AnalogInput_Channels,
                   &identification_moteur_B.AnalogInput, &parm);
  }

  /* Sum: '<Root>/Add1' */
  rtb_Add1 = identification_moteur_B.FromWorkspace -
    identification_moteur_B.AnalogInput;

  /* Sum: '<Root>/Add2' incorporates:
   *  DiscreteIntegrator: '<Root>/Discrete-Time Integrator'
   *  Gain: '<Root>/Gain'
   */
  identification_moteur_B.Add2 = identification_moteur_P.Gain_Gain * rtb_Add1 +
    identification_moteur_DW.DiscreteTimeIntegrator_DSTATE;

  /* S-Function (sldrtao): '<Root>/Analog Output' */
  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) identification_moteur_P.AnalogOutput_RangeMode;
      parm.rangeidx = identification_moteur_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &identification_moteur_P.AnalogOutput_Channels, ((real_T*)
        (&identification_moteur_B.Add2)), &parm);
    }
  }

  /* Gain: '<Root>/Gain1' */
  identification_moteur_B.Gain1 = identification_moteur_P.Gain1_Gain * rtb_Add1;
}

/* Model update function */
void identification_moteur_update(void)
{
  /* Update for DiscreteIntegrator: '<Root>/Discrete-Time Integrator' */
  identification_moteur_DW.DiscreteTimeIntegrator_DSTATE +=
    identification_moteur_P.DiscreteTimeIntegrator_gainval *
    identification_moteur_B.Gain1;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++identification_moteur_M->Timing.clockTick0)) {
    ++identification_moteur_M->Timing.clockTickH0;
  }

  identification_moteur_M->Timing.t[0] =
    identification_moteur_M->Timing.clockTick0 *
    identification_moteur_M->Timing.stepSize0 +
    identification_moteur_M->Timing.clockTickH0 *
    identification_moteur_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void identification_moteur_initialize(void)
{
  /* Start for FromWorkspace: '<Root>/From Workspace' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.21193477192928487,
      0.42386954385856973, 0.63580431578785457, 0.84773908771713946,
      1.0596738596464244, 1.2716086315757091, 1.4835434035049941,
      1.6954781754342789, 1.9074129473635637, 2.1193477192928487,
      2.3312824912221335, 2.5432172631514183, 2.7551520350807031,
      2.9670868070099883, 3.1790215789392731, 3.3909563508685578,
      3.6028911227978426, 3.8148258947271274, 4.0267606666564122,
      4.2386954385856974, 4.4506302105149818, 4.662564982444267,
      4.8744997543735522, 5.0864345263028365, 5.2983692982321218,
      5.5103040701614061, 5.7222388420906913, 5.9341736140199766,
      6.1461083859492609, 6.3580431578785461, 6.5699779298078305,
      6.7819127017371157, 6.9938474736664009, 7.2057822455956853,
      7.4177170175249705, 7.6296517894542548, 7.84158656138354,
      8.0535213333128244, 8.26545610524211, 8.4773908771713948, 8.68932564910068,
      8.9012604210299635, 9.11319519295925, 9.325129964888534,
      9.5370647368178183, 9.7489995087471044, 9.9609342806763888,
      10.172869052605673, 10.384803824534959, 10.596738596464244,
      10.808673368393528, 11.020608140322812, 11.232542912252098,
      11.444477684181383, 11.656412456110667, 11.868347228039953,
      12.080281999969237, 12.292216771898522, 12.504151543827808,
      12.716086315757092, 12.928021087686377, 13.139955859615661,
      13.351890631544947, 13.563825403474231, 13.775760175403516,
      13.987694947332802, 14.199629719262086, 14.411564491191371,
      14.623499263120655, 14.835434035049941, 15.047368806979225,
      15.25930357890851, 15.471238350837796, 15.68317312276708,
      15.895107894696364, 16.107042666625649, 16.318977438554935,
      16.530912210484221, 16.742846982413504, 16.95478175434279,
      17.166716526272076, 17.378651298201358, 17.590586070130644,
      17.802520842059927, 18.014455613989213, 18.2263903859185,
      18.438325157847782, 18.650259929777068, 18.862194701706354,
      19.074129473635637, 19.286064245564923, 19.497999017494209,
      19.709933789423491, 19.921868561352778, 20.133803333282064,
      20.345738105211346, 20.557672877140632, 20.769607649069918,
      20.9815424209992, 21.193477192928487, 21.40541196485777,
      21.617346736787056, 21.829281508716342, 22.041216280645624,
      22.253151052574911, 22.465085824504197, 22.677020596433479,
      22.888955368362765, 23.100890140292051, 23.312824912221334,
      23.52475968415062, 23.736694456079906, 23.948629228009189,
      24.160563999938475, 24.372498771867761, 24.584433543797044,
      24.79636831572633, 25.008303087655616, 25.2202378595849,
      25.432172631514185, 25.644107403443467, 25.856042175372753,
      26.067976947302039, 26.279911719231322, 26.491846491160608,
      26.703781263089894, 26.915716035019177, 27.127650806948463,
      27.339585578877749, 27.551520350807031, 27.763455122736318,
      27.975389894665604, 28.187324666594886, 28.399259438524172,
      28.611194210453458, 28.823128982382741, 29.035063754312027,
      29.24699852624131, 29.458933298170596, 29.670868070099882,
      29.882802842029164, 30.094737613958451, 30.306672385887737,
      30.518607157817019, 30.730541929746305, 30.942476701675591,
      31.154411473604874, 31.36634624553416, 31.578281017463446,
      31.790215789392729, 32.002150561322011, 32.2140853332513,
      32.426020105180584, 32.63795487710987, 32.849889649039156,
      33.061824420968442, 33.273759192897721, 33.485693964827007,
      33.697628736756293, 33.909563508685579, 34.121498280614865,
      34.333433052544152, 34.545367824473431, 34.757302596402717,
      34.969237368332, 35.181172140261289, 35.393106912190575,
      35.605041684119854, 35.81697645604914, 36.028911227978426,
      36.240845999907712, 36.452780771837, 36.664715543766285,
      36.876650315695564, 37.08858508762485, 37.300519859554136,
      37.512454631483422, 37.724389403412708, 37.936324175341994,
      38.148258947271273, 38.360193719200559, 38.572128491129845,
      38.784063263059132, 38.995998034988418, 39.2079328069177,
      39.419867578846983, 39.631802350776269, 39.843737122705555,
      40.055671894634841, 40.267606666564127, 40.479541438493406,
      40.691476210422692, 40.903410982351978, 41.115345754281265,
      41.327280526210551, 41.539215298139837, 41.751150070069116,
      41.9630848419984, 42.175019613927688, 42.386954385856974,
      42.59888915778626, 42.810823929715539, 43.022758701644825,
      43.234693473574112, 43.4466282455034, 43.658563017432684,
      43.87049778936197, 44.082432561291249, 44.294367333220535,
      44.506302105149821, 44.718236877079107, 44.930171649008393,
      45.142106420937679, 45.354041192866958, 45.565975964796245,
      45.777910736725531, 45.989845508654817, 46.2017802805841,
      46.413715052513389, 46.625649824442668, 46.837584596371954,
      47.04951936830124, 47.261454140230526, 47.473388912159812,
      47.685323684089092, 47.897258456018378, 48.109193227947664,
      48.32112799987695, 48.533062771806236, 48.744997543735522,
      48.9569323156648, 49.168867087594087, 49.380801859523373,
      49.592736631452659, 49.804671403381946, 50.016606175311232,
      50.228540947240511, 50.4404757191698, 50.652410491099083,
      50.864345263028369, 51.076280034957655, 51.288214806886934,
      51.50014957881622, 51.712084350745506, 51.924019122674792,
      52.135953894604079, 52.347888666533365, 52.559823438462644,
      52.771758210391923, 52.983692982321209, 53.195627754250495,
      53.407562526179781, 53.619497298109067, 53.831432070038353,
      54.043366841967632, 54.255301613896918, 54.467236385826205,
      54.679171157755491, 54.891105929684777, 55.103040701614056,
      55.314975473543342, 55.526910245472628, 55.738845017401914,
      55.9507797893312, 56.162714561260486, 56.374649333189765,
      56.586584105119051, 56.798518877048338, 57.010453648977624,
      57.22238842090691, 57.434323192836196, 57.646257964765475,
      57.858192736694761, 58.070127508624047, 58.282062280553333,
      58.493997052482619, 58.7059318244119, 58.917866596341185,
      59.129801368270471, 59.341736140199757, 59.553670912129043,
      59.765605684058329, 59.977540455987608, 60.189475227916894,
      60.40140999984618, 60.613344771775466, 60.825279543704752,
      61.037214315634039, 61.249149087563318, 61.461083859492604,
      61.67301863142189, 61.884953403351176, 62.096888175280462,
      62.308822947209748, 62.520757719139027, 62.732692491068313,
      62.9446272629976, 63.156562034926885, 63.368496806856172,
      63.580431578785451, 63.792366350714737, 64.004301122644023,
      64.216235894573316, 64.4281706665026, 64.640105438431874,
      64.852040210361167, 65.063974982290446, 65.275909754219725,
      65.487844526149019, 65.699779298078312, 65.911714070007591,
      66.12364884193687, 66.335583613866163, 66.547518385795442,
      66.759453157724721, 66.971387929654014, 67.1833227015833,
      67.395257473512572, 67.607192245441865, 67.819127017371159,
      68.031061789300438, 68.242996561229717, 68.45493133315901,
      68.666866105088289, 68.878800877017568, 69.090735648946861,
      69.302670420876154, 69.514605192805433, 69.726539964734712,
      69.938474736664, 70.150409508593285, 70.362344280522564,
      70.574279052451857, 70.786213824381136, 70.998148596310415,
      71.210083368239708, 71.422018140169, 71.63395291209828, 71.845887684027559,
      72.057822455956853, 72.269757227886132, 72.481691999815411,
      72.6936267717447, 72.905561543674, 73.117496315603276, 73.329431087532555,
      73.541365859461848, 73.753300631391127, 73.9652354033204, 74.1771701752497,
      74.389104947178978, 74.601039719108272, 74.812974491037551,
      75.024909262966844, 75.236844034896123, 75.4487788068254, 75.6607135787547,
      75.872648350683974, 76.084583122613253, 76.296517894542546,
      76.508452666471825, 76.720387438401119, 76.9323222103304,
      77.144256982259691, 77.35619175418897, 77.568126526118249,
      77.780061298047542, 77.991996069976821, 78.203930841906114,
      78.4158656138354, 78.627800385764687, 78.839735157693966,
      79.051669929623245, 79.263604701552538, 79.475539473481817,
      79.6874742454111, 79.899409017340389, 80.111343789269668,
      80.323278561198961, 80.53521333312824, 80.747148105057533,
      80.959082876986812, 81.171017648916092, 81.382952420845385,
      81.594887192774664, 81.806821964703957, 82.018756736633236,
      82.230691508562529, 82.442626280491808, 82.654561052421087,
      82.86649582435038, 83.078430596279659, 83.290365368208938,
      83.502300140138232, 83.714234912067525, 83.9261696839968,
      84.138104455926083, 84.350039227855376, 84.561973999784655,
      84.773908771713934, 84.985843543643227, 85.1977783155725, 85.4097130875018,
      85.621647859431079, 85.833582631360372, 86.045517403289651,
      86.25745217521893, 86.469386947148223, 86.6813217190775,
      86.893256491006781, 87.105191262936074, 87.317126034865368,
      87.529060806794647, 87.740995578723926, 87.952930350653219,
      88.1648651225825, 88.376799894511777, 88.58873466644107,
      88.800669438370349, 89.012604210299642, 89.224538982228921,
      89.436473754158214, 89.6484085260875, 89.860343298016772,
      90.072278069946066, 90.284212841875345, 90.496147613804638,
      90.708082385733917, 90.9200171576632, 91.131951929592489,
      91.343886701521768, 91.555821473451061, 91.76775624538034,
      91.979691017309619, 92.191625789238913, 92.403560561168192,
      92.615495333097485, 92.827430105026764, 93.039364876956057,
      93.251299648885336, 93.463234420814615, 93.675169192743908,
      93.887103964673187, 94.099038736602481, 94.31097350853176,
      94.522908280461039, 94.734843052390332, 94.946777824319611,
      95.1587125962489, 95.370647368178183, 95.582582140107462,
      95.794516912036755, 96.006451683966034, 96.218386455895327,
      96.4303212278246, 96.6422559997539, 96.854190771683179, 97.066125543612458,
      97.278060315541751, 97.48999508747103, 97.701929859400323,
      97.9138646313296, 98.125799403258881, 98.337734175188174,
      98.549668947117453, 98.761603719046747, 98.973538490976026,
      99.1854732629053, 99.3974080348346, 99.609342806763877, 99.82127757869317,
      100.03321235062245, 100.24514712255174, 100.45708189448102,
      100.6690166664103, 100.88095143833959, 101.09288621026887,
      101.30482098219817, 101.51675575412744, 101.72869052605672,
      101.94062529798602, 102.1525600699153, 102.36449484184459,
      102.57642961377387, 102.78836438570315, 103.00029915763244,
      103.21223392956172, 103.42416870149101, 103.63610347342029,
      103.84803824534958, 104.05997301727886, 104.27190778920814,
      104.48384256113744, 104.69577733306672, 104.90771210499601,
      105.11964687692529 } ;

    static real_T pDataValues0[] = { 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 4.0,
      4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0,
      6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0,
      6.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0,
      4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0,
      4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0,
      4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0,
      6.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0,
      6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0,
      6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0,
      6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0,
      6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0,
      6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 4.0,
      4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0,
      4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0,
      4.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0,
      4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0,
      6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0,
      4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0,
      4.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0,
      4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 4.0,
      4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0,
      6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0,
      6.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0,
      4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0,
      6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0,
      4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0,
      6.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0,
      6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 6.0,
      6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0,
      4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0,
      4.0, 6.0, 6.0, 6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0,
      6.0, 6.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0, 6.0, 6.0,
      6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0 } ;

    identification_moteur_DW.FromWorkspace_PWORK.TimePtr = (void *) pTimeValues0;
    identification_moteur_DW.FromWorkspace_PWORK.DataPtr = (void *) pDataValues0;
    identification_moteur_DW.FromWorkspace_IWORK.PrevIndex = 0;
  }

  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */

  /* no initial value should be set */

  /* InitializeConditions for DiscreteIntegrator: '<Root>/Discrete-Time Integrator' */
  identification_moteur_DW.DiscreteTimeIntegrator_DSTATE =
    identification_moteur_P.DiscreteTimeIntegrator_IC;
}

/* Model terminate function */
void identification_moteur_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */

  /* no final value should be set */
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  identification_moteur_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  identification_moteur_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  identification_moteur_initialize();
}

void MdlTerminate(void)
{
  identification_moteur_terminate();
}

/* Registration function */
RT_MODEL_identification_moteur_T *identification_moteur(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  identification_moteur_P.AnalogInput_MaxMissedTicks = rtInf;
  identification_moteur_P.AnalogOutput_MaxMissedTicks = rtInf;

  /* initialize real-time model */
  (void) memset((void *)identification_moteur_M, 0,
                sizeof(RT_MODEL_identification_moteur_T));

  /* Initialize timing info */
  {
    int_T *mdlTsMap = identification_moteur_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    identification_moteur_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    identification_moteur_M->Timing.sampleTimes =
      (&identification_moteur_M->Timing.sampleTimesArray[0]);
    identification_moteur_M->Timing.offsetTimes =
      (&identification_moteur_M->Timing.offsetTimesArray[0]);

    /* task periods */
    identification_moteur_M->Timing.sampleTimes[0] = (0.001);

    /* task offsets */
    identification_moteur_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(identification_moteur_M, &identification_moteur_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = identification_moteur_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    identification_moteur_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(identification_moteur_M, 50.0);
  identification_moteur_M->Timing.stepSize0 = 0.001;

  /* External mode info */
  identification_moteur_M->Sizes.checksums[0] = (2453767390U);
  identification_moteur_M->Sizes.checksums[1] = (425178143U);
  identification_moteur_M->Sizes.checksums[2] = (828137863U);
  identification_moteur_M->Sizes.checksums[3] = (1173476347U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    identification_moteur_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(identification_moteur_M->extModeInfo,
      &identification_moteur_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(identification_moteur_M->extModeInfo,
                        identification_moteur_M->Sizes.checksums);
    rteiSetTPtr(identification_moteur_M->extModeInfo, rtmGetTPtr
                (identification_moteur_M));
  }

  identification_moteur_M->solverInfoPtr = (&identification_moteur_M->solverInfo);
  identification_moteur_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&identification_moteur_M->solverInfo, 0.001);
  rtsiSetSolverMode(&identification_moteur_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  identification_moteur_M->blockIO = ((void *) &identification_moteur_B);
  (void) memset(((void *) &identification_moteur_B), 0,
                sizeof(B_identification_moteur_T));

  /* parameters */
  identification_moteur_M->defaultParam = ((real_T *)&identification_moteur_P);

  /* states (dwork) */
  identification_moteur_M->dwork = ((void *) &identification_moteur_DW);
  (void) memset((void *)&identification_moteur_DW, 0,
                sizeof(DW_identification_moteur_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    identification_moteur_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  identification_moteur_M->Sizes.numContStates = (0);/* Number of continuous states */
  identification_moteur_M->Sizes.numY = (0);/* Number of model outputs */
  identification_moteur_M->Sizes.numU = (0);/* Number of model inputs */
  identification_moteur_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  identification_moteur_M->Sizes.numSampTimes = (1);/* Number of sample times */
  identification_moteur_M->Sizes.numBlocks = (9);/* Number of blocks */
  identification_moteur_M->Sizes.numBlockIO = (4);/* Number of block outputs */
  identification_moteur_M->Sizes.numBlockPrms = (14);/* Sum of parameter "widths" */
  return identification_moteur_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
