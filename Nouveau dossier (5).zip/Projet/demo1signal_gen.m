% DEMO SIGNAL GENERATION 
% Author: C. Poussot-Vassal [MOR Digital Systems / Onera]
% Date  : March 2022 (creation)
% 
% Description
% Demonstration script for identification signals construction. This small 
% script illustrates how one can generate different excitation signals in 
% view of model identification. This script is a rather simple one and 
% modifications may be applied by users. Still, it provides a first 
% shot for it, but does not prevent for additional reading and thinking.
% Among others, one can consider, the analysis of the frequency spectra,
% the length, the applicability... of each input/output couples
% 
% Note
% The script uses the "+insa" matlab package.
% 
% INSA demonstrators available in 2022
%  * billes sur rail (4)
%  * moteurs (6)
%  * balle de ping-pong (1)
%  * Soufflerie (1)
%  * Niveau d'eau (plusieurs)
%  * ailettes (3)
% 


close all, clc;
load ss1.mat;
% >> Graphic settings
%rng(12345)
insa.initGraphics

Te = 0.001;

% >> System to identify
G  = tf([1 -2],[.1 .4 1]);
S  = stepinfo(G);
n  = 5e-2; % noise
Fn = tf(n,[1/10 1]);

% >> PRBS CASE (constructs u1,y1,y1n)
% Generate exciting signal
N       = 5;
Tr      = S.SettlingTime*2;
Ts      = Tr/20;
P       = 4;
Plot    = 0;
[u1,t1] = insa.prbs(Ts,N,Tr,P,Plot);

% Apply to system to be identified
y1      = lsim(G,u1,t1);
% Add noise
y1n     = y1 .* (1 + lsim(Fn,randn(numel(y1),1),t1));

% >> CHIRP CASE (constructs u2,y2,y2n)
% Generate exciting signal
Wmax    = 7/S.SettlingTime;
f1      = 3*Wmax/(2*pi);
t2      = 0:1/f1/10:50;
f0      = 1e-2;
tend    = t2(end);
type    = 'linear';% 'logarithmic';
u2      = insa.chirp(t2,f0,tend,f1,type);
% Apply to system to be identified
y2      = lsim(G,u2,t2);
% Add noise
y2n     = y2 .* (1 + lsim(Fn,randn(numel(y2),1),t2));


% >> RANDOM CASE (constructs u3,y3,y3n)
% Generate exciting signal
t3      = 0:Ts:10;
u3      = rand(1,length(t3))-.5;
% Apply to system to be identified
y3      = lsim(G,u3,t3);
% Add noise
y3n     = y3 .* (1 + lsim(Fn,randn(numel(y3),1),t3));


% >> IMPULSE CASE (constructs u4,y4,y4n)
% Generate exciting signal
t4      = 0:Ts:10;
u4      = zeros(1,length(t4)); u4(1) = 1/Ts;
% Apply to system to be identified
y4      = lsim(G,u4,t4);
% Add noise
y4n     = y4 .* (1 + lsim(Fn,randn(numel(y4),1),t4));


save('signals','G','t1','u1','y1','y1n', ...
                   't2','u2','y2','y2n', ...
                   't3','u3','y3','y3n', ...
                   't4','u4','y4','y4n')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NOUS

% Us = [t1.',u1+5];
% 
% out = sim("identification_moteur");
% toWksDataOUT = get(out,"simout1");
% toWksDataIN = get(out,"simout");
% toWksDataERROR = get(out,"simout2");
% output = toWksDataOUT.Data;
% input = toWksDataIN.Data;
% error = toWksDataERROR.Data;
% 
% 
% Us = [t2.',u2+5];
% 
% out = sim("identification_moteur");
% toWksDataOUT2 = get(out,"simout1");
% toWksDataIN2 = get(out,"simout");
% toWksDataERROR2 = get(out,"simout2");
% output2 = toWksDataOUT2.Data;
% input2 = toWksDataIN2.Data;
% error2 = toWksDataERROR2.Data;
% Frequency = f0:(f1-f0)/50000:f1;
% 
% E = 1/error.size*sum(abs(error./input2))
% Hd = tf([0.006316 0],[1 -0.9927],Te)
% H = d2c(Hd)

% Us = [t1.',u1+4];
% 
% out = sim("identification_balle");
% toWksDataOUT = get(out,"simout2");
% toWksDataIN = get(out,"simout3");
% 
% output = toWksDataOUT.Data;
% input = toWksDataIN.Data;
% 
% Us = [t2.',u2+4];
% 
% out = sim("identification_balle");
% toWksDataOUT2 = get(out,"simout2");
% toWksDataIN2 = get(out,"simout3");
%  
% output2 = toWksDataOUT2.Data;
% input2 = toWksDataIN2.Data;

% out = sim("identification_balle");
% toWksDataIN2 = get(out,"simout3");
% output2 = toWksDataIN2.Data;
% input2 = toWksDataIN2.Data;

T = 0:Te:0.8;
X_theorique = -9.81/2 * T .* T + 0.77;
X_reel = output2(10000:10800);

fun = @(x) norm(X_theorique - (x(1) + x(2).* X_reel));

x0 = [0,0];
[x,fval] = fminunc(fun,x0)

% Ecart = X_reel - X_theorique';

G = tf([9.81],[1 0 0]);
% nyquist(G);
% figure
% bode(G);

w = 10;
Gdb = -20;

a = 14;
Ta = 1/w/sqrt(a);
Kp = 10^(-Gdb/20)/sqrt(a);

Y = tf(Kp*[a*Ta 1],[Ta 1]);
nyquist(Y);
figure
bode(Y);
Yd = c2d(Y,Te)




