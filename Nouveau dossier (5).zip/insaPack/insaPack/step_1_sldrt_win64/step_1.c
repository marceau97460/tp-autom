/*
 * step_1.c
 *
 * Classroom License -- for classroom instructional use only.  Not for
 * government, commercial, academic research, or other organizational use.
 *
 * Code generation for model "step_1".
 *
 * Model version              : 1.1
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Thu Apr 20 17:22:07 2023
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "step_1.h"
#include "step_1_private.h"
#include "step_1_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  255.0,
  0.0,
  0.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.01, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6024E", 4294967295U, 6, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_step_1_T step_1_B;

/* Block states (default storage) */
DW_step_1_T step_1_DW;

/* Real-time model */
RT_MODEL_step_1_T step_1_M_;
RT_MODEL_step_1_T *const step_1_M = &step_1_M_;

/* Model output function */
void step_1_output(void)
{
  /* FromWorkspace: '<Root>/From Workspace' */
  {
    real_T *pDataValues = (real_T *) step_1_DW.FromWorkspace_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *) step_1_DW.FromWorkspace_PWORK.TimePtr;
    int_T currTimeIndex = step_1_DW.FromWorkspace_IWORK.PrevIndex;
    real_T t = step_1_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[558]) {
      currTimeIndex = 557;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    step_1_DW.FromWorkspace_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          step_1_B.FromWorkspace = pDataValues[currTimeIndex];
        } else {
          step_1_B.FromWorkspace = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        step_1_B.FromWorkspace = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 559;
      }
    }
  }

  /* S-Function (sldrtai): '<Root>/Analog Input' */
  /* S-Function Block: <Root>/Analog Input */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE) step_1_P.AnalogInput_RangeMode;
    parm.rangeidx = step_1_P.AnalogInput_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1, &step_1_P.AnalogInput_Channels,
                   &step_1_B.AnalogInput, &parm);
  }

  /* Sum: '<Root>/Sum' */
  step_1_B.Sum = step_1_B.FromWorkspace - step_1_B.AnalogInput;

  /* S-Function (sldrtao): '<Root>/Analog Output' */
  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) step_1_P.AnalogOutput_RangeMode;
      parm.rangeidx = step_1_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &step_1_P.AnalogOutput_Channels, ((real_T*) (&step_1_B.Sum)),
                     &parm);
    }
  }
}

/* Model update function */
void step_1_update(void)
{
  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++step_1_M->Timing.clockTick0)) {
    ++step_1_M->Timing.clockTickH0;
  }

  step_1_M->Timing.t[0] = step_1_M->Timing.clockTick0 *
    step_1_M->Timing.stepSize0 + step_1_M->Timing.clockTickH0 *
    step_1_M->Timing.stepSize0 * 4294967296.0;

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++step_1_M->Timing.clockTick1)) {
      ++step_1_M->Timing.clockTickH1;
    }

    step_1_M->Timing.t[1] = step_1_M->Timing.clockTick1 *
      step_1_M->Timing.stepSize1 + step_1_M->Timing.clockTickH1 *
      step_1_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Model initialize function */
void step_1_initialize(void)
{
  /* Start for FromWorkspace: '<Root>/From Workspace' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.5483, 1.0966, 1.6449, 2.1932,
      2.7415000000000003, 3.2898, 3.8381, 4.3864, 4.9347, 5.4830000000000005,
      6.0313, 6.5796, 7.1279, 7.6762, 8.2245, 8.7728, 9.3211, 9.8694, 10.4177,
      10.966000000000001, 11.5143, 12.0626, 12.6109, 13.1592, 13.7075, 14.2558,
      14.8041, 15.3524, 15.9007, 16.449, 16.9973, 17.5456, 18.0939, 18.6422,
      19.1905, 19.7388, 20.2871, 20.8354, 21.3837, 21.932000000000002, 22.4803,
      23.0286, 23.576900000000002, 24.1252, 24.6735, 25.2218, 25.7701, 26.3184,
      26.8667, 27.415, 27.9633, 28.5116, 29.0599, 29.6082, 30.1565, 30.7048,
      31.2531, 31.8014, 32.3497, 32.898, 33.4463, 33.9946, 34.5429, 35.0912,
      35.6395, 36.1878, 36.7361, 37.2844, 37.8327, 38.381, 38.9293, 39.4776,
      40.0259, 40.5742, 41.1225, 41.6708, 42.2191, 42.7674, 43.3157,
      43.864000000000004, 44.4123, 44.9606, 45.508900000000004, 46.0572, 46.6055,
      47.153800000000004, 47.7021, 48.2504, 48.798700000000004, 49.347, 49.8953,
      50.4436, 50.9919, 51.5402, 52.0885, 52.6368, 53.1851, 53.7334, 54.2817,
      54.83, 55.3783, 55.9266, 56.4749, 57.0232, 57.5715, 58.1198, 58.6681,
      59.2164, 59.7647, 60.313, 60.8613, 61.4096, 61.9579, 62.5062,
      63.054500000000004, 63.6028, 64.1511, 64.6994, 65.2477, 65.796, 66.3443,
      66.8926, 67.4409, 67.9892, 68.5375, 69.0858, 69.6341, 70.1824, 70.7307,
      71.279, 71.827300000000008, 72.3756, 72.9239, 73.4722, 74.0205, 74.5688,
      75.117100000000008, 75.6654, 76.2137, 76.762, 77.3103, 77.8586,
      78.406900000000007, 78.9552, 79.5035, 80.0518, 80.6001, 81.1484, 81.6967,
      82.245, 82.7933, 83.3416, 83.8899, 84.4382, 84.9865, 85.5348, 86.0831,
      86.6314, 87.1797, 87.728000000000009, 88.2763, 88.8246, 89.3729, 89.9212,
      90.4695, 91.017800000000008, 91.5661, 92.1144, 92.6627, 93.211, 93.7593,
      94.307600000000008, 94.8559, 95.4042, 95.9525, 96.5008, 97.0491,
      97.597400000000007, 98.1457, 98.694, 99.2423, 99.7906, 100.3389, 100.8872,
      101.4355, 101.9838, 102.5321, 103.0804, 103.6287, 104.177, 104.7253,
      105.2736, 105.8219, 106.3702, 106.91850000000001, 107.4668, 108.0151,
      108.5634, 109.1117, 109.66, 110.20830000000001, 110.7566, 111.3049,
      111.8532, 112.4015, 112.9498, 113.49810000000001, 114.0464, 114.5947,
      115.143, 115.6913, 116.2396, 116.78790000000001, 117.3362, 117.8845,
      118.4328, 118.9811, 119.5294, 120.07770000000001, 120.626, 121.1743,
      121.7226, 122.2709, 122.8192, 123.3675, 123.9158, 124.4641, 125.0124,
      125.5607, 126.10900000000001, 126.6573, 127.2056, 127.7539, 128.3022,
      128.8505, 129.3988, 129.9471, 130.4954, 131.0437, 131.592, 132.1403,
      132.6886, 133.2369, 133.7852, 134.33350000000002, 134.8818, 135.4301,
      135.9784, 136.5267, 137.075, 137.6233, 138.1716, 138.7199, 139.2682,
      139.8165, 140.3648, 140.91310000000001, 141.4614, 142.0097, 142.558,
      143.1063, 143.65460000000002, 144.2029, 144.7512, 145.2995, 145.8478,
      146.3961, 146.9444, 147.4927, 148.041, 148.5893, 149.1376, 149.6859,
      150.23420000000002, 150.7825, 151.3308, 151.8791, 152.4274, 152.9757,
      153.52399999999997, 154.07229999999998, 154.62059999999997,
      155.16889999999998, 155.71719999999996, 156.26549999999997, 156.8138,
      157.36209999999997, 157.91039999999998, 158.45869999999996,
      159.00699999999998, 159.5553, 160.10359999999997, 160.65189999999998,
      161.20019999999997, 161.74849999999998, 162.29679999999996,
      162.84509999999997, 163.39339999999999, 163.94169999999997,
      164.48999999999998, 165.03829999999996, 165.58659999999998, 166.1349,
      166.68319999999997, 167.23149999999998, 167.77979999999997,
      168.32809999999998, 168.8764, 169.42469999999997, 169.97299999999998,
      170.52129999999997, 171.06959999999998, 171.61789999999996,
      172.16619999999998, 172.7145, 173.26279999999997, 173.81109999999998,
      174.35939999999997, 174.90769999999998, 175.456, 176.00429999999997,
      176.55259999999998, 177.10089999999997, 177.64919999999998, 178.1975,
      178.74579999999997, 179.29409999999996, 179.84239999999997,
      180.39069999999998, 180.93899999999996, 181.48729999999998, 182.0356,
      182.58389999999997, 183.13219999999998, 183.6805, 184.22879999999998,
      184.77709999999996, 185.32539999999997, 185.87369999999999,
      186.42199999999997, 186.97029999999998, 187.5186, 188.06689999999998,
      188.61519999999996, 189.16349999999997, 189.71179999999998,
      190.26009999999997, 190.80839999999998, 191.3567, 191.90499999999997,
      192.45329999999996, 193.0016, 193.54989999999998, 194.09819999999996,
      194.64649999999997, 195.1948, 195.74309999999997, 196.29139999999998,
      196.8397, 197.38799999999998, 197.93629999999996, 198.48459999999997,
      199.03289999999998, 199.58119999999997, 200.12949999999998, 200.6778,
      201.22609999999997, 201.77439999999996, 202.3227, 202.87099999999998,
      203.41929999999996, 203.96759999999998, 204.5159, 205.06419999999997,
      205.61249999999998, 206.1608, 206.70909999999998, 207.25739999999996,
      207.80569999999997, 208.35399999999998, 208.90229999999997,
      209.45059999999998, 209.9989, 210.54719999999998, 211.09549999999996,
      211.64379999999997, 212.19209999999998, 212.74039999999997,
      213.28869999999998, 213.837, 214.38529999999997, 214.93359999999996,
      215.4819, 216.03019999999998, 216.57849999999996, 217.12679999999997,
      217.6751, 218.22339999999997, 218.77169999999998, 219.32,
      219.86829999999998, 220.41659999999996, 220.96489999999997,
      221.51319999999998, 222.06149999999997, 222.60979999999998, 223.1581,
      223.70639999999997, 224.25469999999996, 224.803, 225.35129999999998,
      225.89959999999996, 226.44789999999998, 226.9962, 227.54449999999997,
      228.09279999999998, 228.6411, 229.18939999999998, 229.73769999999996,
      230.28599999999997, 230.83429999999998, 231.38259999999997,
      231.93089999999998, 232.4792, 233.02749999999997, 233.57579999999996,
      234.12409999999997, 234.67239999999998, 235.22069999999997,
      235.76899999999998, 236.3173, 236.86559999999997, 237.41389999999998,
      237.9622, 238.51049999999998, 239.05879999999996, 239.60709999999997,
      240.1554, 240.70369999999997, 241.25199999999998, 241.8003,
      242.34859999999998, 242.89689999999996, 243.44519999999997,
      243.99349999999998, 244.54179999999997, 245.09009999999998, 245.6384,
      246.18669999999997, 246.73499999999999, 247.28329999999997,
      247.83159999999998, 248.37989999999996, 248.92819999999998, 249.4765,
      250.02479999999997, 250.57309999999998, 251.1214, 251.66969999999998,
      252.21799999999996, 252.76629999999997, 253.31459999999998,
      253.86289999999997, 254.41119999999998, 254.9595, 255.50779999999997,
      256.05609999999996, 256.6044, 257.1527, 257.70099999999996,
      258.24929999999995, 258.7976, 259.3459, 259.89419999999996, 260.4425,
      260.9908, 261.53909999999996, 262.0874, 262.6357, 263.18399999999997,
      263.7323, 264.2806, 264.8289, 265.37719999999996, 265.9255, 266.4738,
      267.02209999999997, 267.57039999999995, 268.1187, 268.667,
      269.21529999999996, 269.7636, 270.3119, 270.86019999999996, 271.4085,
      271.9568, 272.50509999999997, 273.05339999999995, 273.6017, 274.15,
      274.69829999999996, 275.2466, 275.7949, 276.34319999999997,
      276.89149999999995, 277.4398, 277.9881, 278.53639999999996, 279.0847,
      279.633, 280.18129999999996, 280.7296, 281.2779, 281.8262,
      282.37449999999995, 282.9228, 283.4711, 284.01939999999996, 284.5677,
      285.116, 285.66429999999997, 286.21259999999995, 286.7609, 287.3092,
      287.85749999999996, 288.4058, 288.9541, 289.50239999999997, 290.0507,
      290.599, 291.1473, 291.69559999999996, 292.2439, 292.7922,
      293.34049999999996, 293.8888, 294.4371, 294.98539999999997,
      295.53369999999995, 296.082, 296.6303, 297.17859999999996, 297.7269,
      298.2752, 298.82349999999997, 299.37179999999995, 299.9201, 300.4684,
      301.01669999999996, 301.565, 302.1133, 302.66159999999996, 303.2099,
      303.7582, 304.30649999999997, 304.85479999999995, 305.4031, 305.9514 } ;

    static real_T pDataValues0[] = { 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8,
      2.8, 1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8,
      2.8, 1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8,
      2.8, 1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8,
      2.8, 1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8,
      2.8, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003, 2.8, 2.8, 2.8, 2.8,
      1.8000000000000003, 1.8000000000000003, 1.8000000000000003,
      1.8000000000000003, 2.8, 2.8, 2.8, 2.8, 1.8000000000000003,
      1.8000000000000003, 1.8000000000000003 } ;

    step_1_DW.FromWorkspace_PWORK.TimePtr = (void *) pTimeValues0;
    step_1_DW.FromWorkspace_PWORK.DataPtr = (void *) pDataValues0;
    step_1_DW.FromWorkspace_IWORK.PrevIndex = 0;
  }

  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) step_1_P.AnalogOutput_RangeMode;
      parm.rangeidx = step_1_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &step_1_P.AnalogOutput_Channels,
                     &step_1_P.AnalogOutput_InitialValue, &parm);
    }
  }
}

/* Model terminate function */
void step_1_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) step_1_P.AnalogOutput_RangeMode;
      parm.rangeidx = step_1_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &step_1_P.AnalogOutput_Channels,
                     &step_1_P.AnalogOutput_FinalValue, &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  step_1_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  step_1_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  step_1_initialize();
}

void MdlTerminate(void)
{
  step_1_terminate();
}

/* Registration function */
RT_MODEL_step_1_T *step_1(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)step_1_M, 0,
                sizeof(RT_MODEL_step_1_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&step_1_M->solverInfo, &step_1_M->Timing.simTimeStep);
    rtsiSetTPtr(&step_1_M->solverInfo, &rtmGetTPtr(step_1_M));
    rtsiSetStepSizePtr(&step_1_M->solverInfo, &step_1_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&step_1_M->solverInfo, (&rtmGetErrorStatus(step_1_M)));
    rtsiSetRTModelPtr(&step_1_M->solverInfo, step_1_M);
  }

  rtsiSetSimTimeStep(&step_1_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&step_1_M->solverInfo,"FixedStepDiscrete");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = step_1_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    step_1_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    step_1_M->Timing.sampleTimes = (&step_1_M->Timing.sampleTimesArray[0]);
    step_1_M->Timing.offsetTimes = (&step_1_M->Timing.offsetTimesArray[0]);

    /* task periods */
    step_1_M->Timing.sampleTimes[0] = (0.0);
    step_1_M->Timing.sampleTimes[1] = (0.01);

    /* task offsets */
    step_1_M->Timing.offsetTimes[0] = (0.0);
    step_1_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(step_1_M, &step_1_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = step_1_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    step_1_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(step_1_M, 20.0);
  step_1_M->Timing.stepSize0 = 0.01;
  step_1_M->Timing.stepSize1 = 0.01;

  /* External mode info */
  step_1_M->Sizes.checksums[0] = (3612291074U);
  step_1_M->Sizes.checksums[1] = (4147548740U);
  step_1_M->Sizes.checksums[2] = (2853590305U);
  step_1_M->Sizes.checksums[3] = (1898834215U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    step_1_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(step_1_M->extModeInfo,
      &step_1_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(step_1_M->extModeInfo, step_1_M->Sizes.checksums);
    rteiSetTPtr(step_1_M->extModeInfo, rtmGetTPtr(step_1_M));
  }

  step_1_M->solverInfoPtr = (&step_1_M->solverInfo);
  step_1_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&step_1_M->solverInfo, 0.01);
  rtsiSetSolverMode(&step_1_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  step_1_M->blockIO = ((void *) &step_1_B);
  (void) memset(((void *) &step_1_B), 0,
                sizeof(B_step_1_T));

  /* parameters */
  step_1_M->defaultParam = ((real_T *)&step_1_P);

  /* states (dwork) */
  step_1_M->dwork = ((void *) &step_1_DW);
  (void) memset((void *)&step_1_DW, 0,
                sizeof(DW_step_1_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    step_1_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  step_1_M->Sizes.numContStates = (0); /* Number of continuous states */
  step_1_M->Sizes.numY = (0);          /* Number of model outputs */
  step_1_M->Sizes.numU = (0);          /* Number of model inputs */
  step_1_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  step_1_M->Sizes.numSampTimes = (2);  /* Number of sample times */
  step_1_M->Sizes.numBlocks = (6);     /* Number of blocks */
  step_1_M->Sizes.numBlockIO = (3);    /* Number of block outputs */
  step_1_M->Sizes.numBlockPrms = (12); /* Sum of parameter "widths" */
  return step_1_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
