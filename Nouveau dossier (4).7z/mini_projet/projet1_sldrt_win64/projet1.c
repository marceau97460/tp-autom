/*
 * projet1.c
 *
 * Classroom License -- for classroom instructional use only.  Not for
 * government, commercial, academic research, or other organizational use.
 *
 * Code generation for model "projet1".
 *
 * Model version              : 1.31
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Tue May 16 17:46:25 2023
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "projet1.h"
#include "projet1_private.h"
#include "projet1_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.01, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6024E", 4294967295U, 6, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_projet1_T projet1_B;

/* Block states (default storage) */
DW_projet1_T projet1_DW;

/* External outputs (root outports fed by signals with default storage) */
ExtY_projet1_T projet1_Y;

/* Real-time model */
RT_MODEL_projet1_T projet1_M_;
RT_MODEL_projet1_T *const projet1_M = &projet1_M_;

/* Model output function */
void projet1_output(void)
{
  /* S-Function (sldrtai): '<Root>/Analog Input' */
  /* S-Function Block: <Root>/Analog Input */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE) projet1_P.AnalogInput_RangeMode;
    parm.rangeidx = projet1_P.AnalogInput_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1, &projet1_P.AnalogInput_Channels,
                   &projet1_B.AnalogInput, &parm);
  }

  /* S-Function (sldrtai): '<Root>/Analog Input1' */
  /* S-Function Block: <Root>/Analog Input1 */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE) projet1_P.AnalogInput1_RangeMode;
    parm.rangeidx = projet1_P.AnalogInput1_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1, &projet1_P.AnalogInput1_Channels,
                   &projet1_B.AnalogInput1, &parm);
  }

  /* Outport: '<Root>/Out1' */
  projet1_Y.out1 = projet1_B.AnalogInput;

  /* Step: '<Root>/Step' */
  if (projet1_M->Timing.t[0] < projet1_P.Step_Time) {
    projet1_B.Step = projet1_P.Step_Y0;
  } else {
    projet1_B.Step = projet1_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */

  /* DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn1' incorporates:
   *  Sum: '<Root>/Sum1'
   */
  projet1_DW.DiscreteTransferFcn1_tmp = (projet1_B.Step -
    projet1_P.DiscreteTransferFcn1_DenCoef[1] *
    projet1_DW.DiscreteTransferFcn1_states) /
    projet1_P.DiscreteTransferFcn1_DenCoef[0];

  /* DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn' incorporates:
   *  DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn1'
   *  Sum: '<Root>/Sum'
   */
  projet1_DW.DiscreteTransferFcn_tmp =
    (((projet1_P.DiscreteTransferFcn1_NumCoef[0] *
       projet1_DW.DiscreteTransferFcn1_tmp +
       projet1_P.DiscreteTransferFcn1_NumCoef[1] *
       projet1_DW.DiscreteTransferFcn1_states) - projet1_B.AnalogInput) -
     projet1_P.DiscreteTransferFcn_DenCoef[1] *
     projet1_DW.DiscreteTransferFcn_states) /
    projet1_P.DiscreteTransferFcn_DenCoef[0];
  projet1_B.DiscreteTransferFcn = projet1_P.DiscreteTransferFcn_NumCoef[0] *
    projet1_DW.DiscreteTransferFcn_tmp + projet1_P.DiscreteTransferFcn_NumCoef[1]
    * projet1_DW.DiscreteTransferFcn_states;

  /* S-Function (sldrtao): '<Root>/Analog Output' */
  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) projet1_P.AnalogOutput_RangeMode;
      parm.rangeidx = projet1_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &projet1_P.AnalogOutput_Channels, ((real_T*)
        (&projet1_B.DiscreteTransferFcn)), &parm);
    }
  }

  /* ToAsyncQueueBlock generated from: '<Root>/Analog Input' */
  {
    {
      double time = projet1_M->Timing.t[0];
      void *pData = (void *)&projet1_B.AnalogInput;
      int32_T size = 1*sizeof(real_T);
      sendToAsyncQueueTgtAppSvc(4099338074U, time, pData, size);
    }
  }
}

/* Model update function */
void projet1_update(void)
{
  /* Update for DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn1' */
  projet1_DW.DiscreteTransferFcn1_states = projet1_DW.DiscreteTransferFcn1_tmp;

  /* Update for DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn' */
  projet1_DW.DiscreteTransferFcn_states = projet1_DW.DiscreteTransferFcn_tmp;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++projet1_M->Timing.clockTick0)) {
    ++projet1_M->Timing.clockTickH0;
  }

  projet1_M->Timing.t[0] = projet1_M->Timing.clockTick0 *
    projet1_M->Timing.stepSize0 + projet1_M->Timing.clockTickH0 *
    projet1_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void projet1_initialize(void)
{
  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) projet1_P.AnalogOutput_RangeMode;
      parm.rangeidx = projet1_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &projet1_P.AnalogOutput_Channels,
                     &projet1_P.AnalogOutput_InitialValue, &parm);
    }
  }

  /* InitializeConditions for DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn1' */
  projet1_DW.DiscreteTransferFcn1_states =
    projet1_P.DiscreteTransferFcn1_InitialStates;

  /* InitializeConditions for DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn' */
  projet1_DW.DiscreteTransferFcn_states =
    projet1_P.DiscreteTransferFcn_InitialStates;
}

/* Model terminate function */
void projet1_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) projet1_P.AnalogOutput_RangeMode;
      parm.rangeidx = projet1_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &projet1_P.AnalogOutput_Channels,
                     &projet1_P.AnalogOutput_FinalValue, &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  projet1_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  projet1_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  projet1_initialize();
}

void MdlTerminate(void)
{
  projet1_terminate();
}

/* Registration function */
RT_MODEL_projet1_T *projet1(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)projet1_M, 0,
                sizeof(RT_MODEL_projet1_T));

  /* Initialize timing info */
  {
    int_T *mdlTsMap = projet1_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    projet1_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    projet1_M->Timing.sampleTimes = (&projet1_M->Timing.sampleTimesArray[0]);
    projet1_M->Timing.offsetTimes = (&projet1_M->Timing.offsetTimesArray[0]);

    /* task periods */
    projet1_M->Timing.sampleTimes[0] = (0.01);

    /* task offsets */
    projet1_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(projet1_M, &projet1_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = projet1_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    projet1_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(projet1_M, 10.0);
  projet1_M->Timing.stepSize0 = 0.01;

  /* External mode info */
  projet1_M->Sizes.checksums[0] = (2611183424U);
  projet1_M->Sizes.checksums[1] = (270359615U);
  projet1_M->Sizes.checksums[2] = (1537887020U);
  projet1_M->Sizes.checksums[3] = (180943170U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    projet1_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(projet1_M->extModeInfo,
      &projet1_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(projet1_M->extModeInfo, projet1_M->Sizes.checksums);
    rteiSetTPtr(projet1_M->extModeInfo, rtmGetTPtr(projet1_M));
  }

  projet1_M->solverInfoPtr = (&projet1_M->solverInfo);
  projet1_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&projet1_M->solverInfo, 0.01);
  rtsiSetSolverMode(&projet1_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  projet1_M->blockIO = ((void *) &projet1_B);
  (void) memset(((void *) &projet1_B), 0,
                sizeof(B_projet1_T));

  /* parameters */
  projet1_M->defaultParam = ((real_T *)&projet1_P);

  /* states (dwork) */
  projet1_M->dwork = ((void *) &projet1_DW);
  (void) memset((void *)&projet1_DW, 0,
                sizeof(DW_projet1_T));

  /* external outputs */
  projet1_M->outputs = (&projet1_Y);
  projet1_Y.out1 = 0.0;

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    projet1_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  projet1_M->Sizes.numContStates = (0);/* Number of continuous states */
  projet1_M->Sizes.numY = (1);         /* Number of model outputs */
  projet1_M->Sizes.numU = (0);         /* Number of model inputs */
  projet1_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  projet1_M->Sizes.numSampTimes = (1); /* Number of sample times */
  projet1_M->Sizes.numBlocks = (11);   /* Number of blocks */
  projet1_M->Sizes.numBlockIO = (6);   /* Number of block outputs */
  projet1_M->Sizes.numBlockPrms = (30);/* Sum of parameter "widths" */
  return projet1_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
