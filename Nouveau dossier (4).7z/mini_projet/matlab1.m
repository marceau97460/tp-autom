clc; 
insa.initGraphics
Te=0.01
k=1
% Generate exciting signal
N       = 5;
Tr      = 0.5;
Ts      = Te;
P       = 4;
Plot    = 0;
[u1,t1] = insa.prbs(Ts,N,Tr,P,Plot);
t2=transpose(t1)
u1=1.5*u1+4;
entrer = [t2,u1];
plot(t1,u1)
figure;
num=[8.61 3.3]
den = [1 0]
PI =tf(num,den)
PIdis = c2d(PI,Te);
balle=tf([0 9.81*0.35],[1 0 0])
bode(balle)
%nichols(balle)
% vitesse=out.vitesse
% entrer=out.entrer
%d=iddata(out.vitesse.Data,out.entrer.Data,Te)
%out.entrer.Data(:)
%out.vitesse.Data(:)
%Correcteur
numC = [0.33 1];
denC = [0.023 1];
C = tf(numC,denC);
Cz = c2d(C,Te);
position = out.position
plot(position);


