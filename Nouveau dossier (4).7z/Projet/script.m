Te = 0.001;

num=26.439*[0.045 1]
den = [1 0]
PI =tf(num,den)
PIdis = c2d(PI,Te);
num1 = [6.387];
den1 = [1 7.347];
M = tf(num1,den1);
num2 = [9.81];
den2 = [1 0 0];
ball= tf(num1,den1);